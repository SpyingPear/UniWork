# Manual checks (short)
- Open `/` and see the list.
- Create a note. Blank title should give an error.
- Edit a note and save.
- Delete a note and make sure it disappears.
- Try `/notes/9999/` and see 404.
