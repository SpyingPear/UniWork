# Use Case Diagram — Sticky Notes

```mermaid
usecaseDiagram
  actor User
  rectangle "Sticky Notes" {
    User --> (Create Note)
    User --> (Read Notes)
    User --> (Update Note)
    User --> (Delete Note)
  }
```
